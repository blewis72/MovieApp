// src/data/moviesData.js

const fetchMoviesData = async (searchValue) => {
  const url = `http://www.omdbapi.com/?s=${searchValue}&apikey=19cfe50b`;
  
  const response = await fetch(url);
  const data = await response.json();

  // Assuming the data contains a 'Search' array of movies
  return Array.isArray(data.Search) ? data.Search : [];
   // Return an array or empty array
};
export const fetchMovieDetails = async (id) => {
  const url = `http://www.omdbapi.com/?i=${id}&apikey=19cfe50b`;
  const response = await fetch(url);
  const data = await response.json();
  return data.Response === 'True' ? data : null; // Return null if not found
};


export default fetchMoviesData;
