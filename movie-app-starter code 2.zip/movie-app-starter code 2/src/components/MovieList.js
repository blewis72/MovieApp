// src/components/MovieList.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import fetchMoviesData from '../data/moviesData'; // Import the fetch function
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';

function MovieList() {
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredMovies, setFilteredMovies] = useState([]);
    const [moviesData, setMoviesData] = useState([]);

    useEffect(() => {
        const loadMovies = async () => {
            const movies = await fetchMoviesData(searchTerm || ''); // Pass the search term
            setMoviesData(movies);
            setFilteredMovies(movies); // Initialize filteredMovies with all movies
        };

        loadMovies();
    }, [searchTerm]); // Dependency on searchTerm to fetch movies when it changes

    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
    };

    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            filterMovies(searchTerm);
        }
    };

    useEffect(() => {
        filterMovies(searchTerm);
    }, [searchTerm, moviesData]);

    const filterMovies = (term) => {
        const filtered = moviesData.filter(movie =>
            movie.Title.toLowerCase().includes(term.toLowerCase())
        );
        setFilteredMovies(filtered);
    };

    return (
        <div>
        <div className="movie-list">
            <h2>Movie List</h2>
            <input
                type="text"
                placeholder="Search movies..."
                value={searchTerm}
            
                onChange={handleSearchChange}
                onKeyDown={handleKeyDown} 
                
              
            />
       </div>
    <div className='container-fluid mov-app'>
     <div className="row">
            
                {filteredMovies.map(movie => (
                    <div   key={movie.imdbID}   className='col-md-3'>
                  
                        <Link to={`/movies/${movie.imdbID}`}>
                            {movie.Title} ({movie.Year}) 
                            <img  className='d-flex justify-content-start m-3' src={movie.Poster} alt={`${movie.Title} poster`} />
                        </Link>
                    
                    </div>
                ))}
            
            </div>
            </div>
            </div>
            
    );
}

export default MovieList;
