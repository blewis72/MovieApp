// src/components/MovieDetail.js
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { fetchMovieDetails } from '../data/moviesData'; // Import the function
import '../App.css';

function MovieDetail() {
    const { id } = useParams(); // Assuming the route is set up to pass the movie ID
    const [movie, setMovie] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchDetails = async () => {
            try {
                const movieData = await fetchMovieDetails(id);
                if (movieData) {
                    setMovie(movieData);
                } else {
                    setError('Movie not found');
                }
            } catch (err) {
                setError('Failed to fetch movie details.');
            } finally {
                setLoading(false);
            }
        };

        fetchDetails();
    }, [id]);

    if (loading) return <h2>Loading...</h2>;
    if (error) return <h2>{error}</h2>;
    if (!movie) return <h2>Movie not found</h2>;

    return (
        <div>
            <h2>{movie.Title} ({movie.Year})</h2>
            <p>Director: {movie.Director}</p>
            <img src={movie.Poster} alt={`${movie.Title} poster`} />
            <p>{movie.Plot}</p>
        </div>
    );
}

export default MovieDetail;
